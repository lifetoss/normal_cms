<?php
	$mysqli=mysqli_connect('localhost','root','','normal_cms') or die('error occur while connecting server');
	
?>